import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) console.warn("OPENAI_API_KEY is missing.");

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.use(express.json({limit:"12mb"}));
app.use(express.static(__dirname));

app.post("/api/chat", async (req,res)=>{
  try{
    if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"Add OPENAI_API_KEY to the server environment first."});
    const incoming = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const messages = incoming.slice(-20);
    const input = messages.map(m=>{
      if(m.image){
        return {role:m.role,content:[
          {type:"input_text",text:m.content||"Please analyze this image."},
          {type:"input_image",image_url:m.image}
        ]};
      }
      return {role:m.role,content:m.content};
    });
    const response = await client.responses.create({
      model: process.env.COBB_MODEL || "gpt-5.6-luna",
      instructions:"You are COBB, a friendly, reliable AI assistant. Give clear useful answers. If an image is provided, analyze it carefully. Never claim to see details that are not visible. Be concise unless the user asks for depth.",
      input
    });
    res.json({reply:response.output_text});
  }catch(err){
    console.error(err);
    res.status(500).json({error:"COBB could not complete the request. Please try again."});
  }
});
app.listen(port,()=>console.log(`COBB running at http://localhost:${port}`));
