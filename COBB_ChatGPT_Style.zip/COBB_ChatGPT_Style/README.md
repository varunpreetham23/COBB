# COBB 2.0 — ChatGPT-style interface

Features:
- Chat history and New Chat
- Local demo Login / Signup UI
- Voice input using the browser Speech Recognition API
- Image upload and AI image analysis
- Responsive mobile app-style interface
- Server-side OpenAI Responses API connection
- API key stays on the server

## Start
1. Install Node.js 18+.
2. Run `npm install`.
3. Set `OPENAI_API_KEY` in your environment.
4. Run `npm start`.
5. Open http://localhost:3000

The Login/Signup in this starter is a local demo stored in the browser. For production, replace it with a real authentication/database service.
Never put the API key in index.html.
